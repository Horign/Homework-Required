import argparse
from pathlib import Path
from course_organizer import build_organize_plan, execute_plan, generate_report


def parse_cli_args():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(description="课程资料自动分类整理器")
    parser.add_argument("--source", required=True, help="原始课程资料所在目录路径")
    parser.add_argument("--target", required=True, help="整理后文件存放的目标目录路径")
    parser.add_argument("--dry-run", action="store_true", help="仅预览整理计划，不实际操作文件")
    parser.add_argument("--mode", choices=["copy", "move"], default="copy", help="文件操作模式：copy复制(默认) / move移动")
    return parser.parse_args()


def main():
    args = parse_cli_args()
    source_dir = Path(args.source).resolve()
    target_dir = Path(args.target).resolve()

    # 源目录合法性校验
    if not source_dir.exists() or not source_dir.is_dir():
        print(f"错误：源目录 {source_dir} 不存在或不是有效文件夹！")
        return

    # 步骤1：生成整理计划（先规划后执行，降低误操作风险）
    plan = build_organize_plan(source_dir, target_dir)
    if len(plan) == 0:
        print("源目录未扫描到任何文件，程序退出")
        return

    # 步骤2：执行计划（预览/复制/移动）
    execute_plan(plan, dry_run=args.dry_run, mode=args.mode)

    # 步骤3：非预览模式生成整理报告
    if not args.dry_run:
        generate_report(target_dir, plan, args.mode)


if __name__ == "__main__":
    main()