\# 课程资料整理器 Course Materials Organizer



\## 项目简介

一个基于 Python 标准库开发的自动化文件整理工具，可将混杂的课件、代码、作业、数据、截图等课程资料，按「关键字优先 + 后缀匹配」规则自动分类归档，支持预览校验、复制/移动双模式、重名自动保护、整理报告生成。



\## 环境要求

\- Python 3.6 及以上版本

\- 仅使用标准库，无需安装任何第三方依赖



\## 项目结构

02\_course\_materials\_organizer/

├── main.py # 程序入口，命令行参数解析

├── course\_organizer/

│ ├── init.py # 包初始化

│ ├── rules.py # 分类规则定义

│ └── core.py # 核心业务逻辑

├── sample\_materials/ # 测试素材目录

└── README.md



\## 使用方法

\### 1. 预览整理计划（推荐先执行，不修改任何文件）

```bash

python main.py --source sample\_materials --target organized\_materials --dry-run



\### 2. 复制模式整理（默认，保留原文件）

```bash

python main.py --source sample\_materials --target organized\_materials
### 3. 移动模式整理（剪切原文件，加分功能）

```bash

python main.py --source sample\_materials --target organized\_materials --mode move

参数说明

参数	必填	说明

\--source	是	原始资料所在文件夹路径

\--target	是	整理后文件存放路径

\--dry-run	否	仅预览计划，不操作文件

\--mode	否	操作模式：copy(默认) / move

分类规则

优先规则：文件名包含「作业、练习、实验、任务」关键字，直接归入 homework 目录；

后缀规则：未匹配关键字时，按文件后缀归入对应分类：

课件：.ppt .pptx .key → slides

代码：.py .ipynb .c .cpp .java → code

数据：.csv .xlsx .json → data

文档：.pdf .doc .docx .txt .md → documents

图片：.png .jpg .jpeg .gif → images

兜底规则：无法识别的后缀归入 others 目录。

安全特性

1\.默认使用复制模式，不删除原始文件；

2\.--dry-run 预览模式不创建任何目录和文件；

3\.目标目录同名文件自动追加 \_1 \_2 后缀，永不覆盖原有文件。

设计思想

1\.先规划后执行：先生成完整整理计划，再统一执行，支持预览校验，降低误操作风险；

2\.模块化拆分：规则、核心逻辑、入口三层分离，修改分类规则无需改动业务代码；

3\.面向对象路径：使用 pathlib.Path 替代字符串路径，跨平台兼容、代码更简洁；

4\.单一职责：每个函数只负责一个功能，便于调试和扩展。



\---



\## 六、学习目标对应解答

\### 1. `Path` 和普通字符串路径有什么区别

\- \*\*本质不同\*\*：字符串路径只是普通文本，`Path` 是面向对象的路径对象，封装了路径相关的所有操作；

\- \*\*拼接方式\*\*：字符串需要手动拼接分隔符（Windows用`\\`、Linux用`/`），容易出错；`Path` 用 `/` 运算符即可拼接，自动适配操作系统；

\- \*\*属性访问\*\*：字符串获取后缀、文件名、父目录需要切片或调用 `os.path` 系列函数；`Path` 直接通过 `.suffix` `.stem` `.parent` 属性获取，代码更简洁易读；

\- \*\*方法集成\*\*：`Path` 自带 `.exists()` `.mkdir()` `.iterdir()` `.write\_text()` 等方法，无需导入 os 模块即可完成大部分路径操作。



\### 2. `argparse` 如何接收命令行参数

分为三步标准流程：

1\. \*\*创建解析器\*\*：实例化 `argparse.ArgumentParser`，可添加程序描述和帮助信息；

2\. \*\*注册参数\*\*：调用 `add\_argument()` 定义参数，支持必填参数、布尔开关、枚举选项、默认值等多种类型；

3\. \*\*解析参数\*\*：调用 `parse\_args()` 读取终端输入，返回 `Namespace` 对象，通过属性名直接获取参数值。



同时 `argparse` 会自动生成 `-h` 帮助文档，并对非法参数、缺失必填参数给出清晰的错误提示，无需手动编写校验逻辑。



\### 3. 为什么要先生成「整理计划」，再真正复制或移动文件

1\. \*\*安全预览\*\*：`dry-run` 模式完全依赖计划列表实现预览，用户可先确认分类结果和目标路径，避免误操作导致文件混乱；

2\. \*\*统一校验\*\*：一次性计算所有文件的目标路径、处理重名冲突，避免执行中途报错导致「部分文件已移动、部分未移动」的不一致状态；

3\. \*\*数据复用\*\*：计划列表可直接用于生成整理报告，无需二次扫描和计算文件；

4\. \*\*解耦设计\*\*：规划逻辑与执行逻辑分离，后续新增移动、删除等操作模式时，无需重写扫描和分类逻辑。



\### 4. 如何用字典保存「后缀名 → 分类目录」的规则

将后缀名作为字典的 key，分类目录名作为 value，集中存储映射关系：

\- 规则集中管理，新增、修改、删除分类只需修改字典，无需改动业务逻辑代码；

\- 查找效率高，通过键值对直接匹配，无需多层 if-else 判断；

\- 可独立抽离到 rules 模块，实现「配置与业务代码分离」，便于维护和测试。

本项目中 `SUFFIX\_CATEGORY\_MAP` 字典就是典型实现。



\### 5. 如何把程序拆成入口文件、核心逻辑模块、分类规则模块

按照「单一职责」原则拆分三层：

\- \*\*入口层（main.py）\*\*：只负责接收命令行参数、校验输入、调度整体流程，不包含任何业务逻辑；

\- \*\*核心逻辑层（core.py）\*\*：实现文件扫描、计划生成、文件操作、报告生成等通用能力，不关心具体分类规则；

\- \*\*规则层（rules.py）\*\*：仅存放分类关键字、后缀映射字典和分类判断函数，纯配置与规则判断。



拆分后各模块职责清晰，便于调试、修改和复用，符合工程化开发的基本思想。



\---



\## 七、提交说明

\### 1. 运行命令与结果（可直接写入作业文档）

\- 命令1：`python main.py --source sample\_materials --target organized\_materials --dry-run`

&#x20; - 结果：终端输出9个文件的分类与目标路径，未创建 `organized\_materials` 目录

\- 命令2：`python main.py --source sample\_materials --target organized\_materials`

&#x20; - 结果：创建目标目录与7个分类子目录，文件全部复制到位，生成「整理报告.txt」



\### 2. 程序体现的 Python 作用

1\. \*\*快速开发自动化脚本\*\*：仅用标准库、百余行代码即可实现文件整理自动化，替代手工重复拖拽操作；

2\. \*\*高效处理文件与批量任务\*\*：`pathlib` 简化路径操作，`shutil` 封装文件复制移动，批量处理目录文件无需人工干预；

3\. \*\*结构化组织代码\*\*：字典、函数、模块三层封装，规则与逻辑分离，程序可维护性大幅提升；

4\. \*\*灵活的命令行工具\*\*：通过 `argparse` 快速封装成 CLI 工具，一次编写可反复调用，适配不同课程文件夹。



\### 3. Git 提交（GitHub）

按功能迭代分多次提交，符合开发规范：

```bash

\# 初始化仓库

git init

git add 题目与要求.md

git commit -m "docs: 添加项目题目与要求文档"



\# 第一次提交：项目骨架与入口

git add main.py course\_organizer/\_\_init\_\_.py

git commit -m "feat: 搭建项目结构，完成命令行参数解析入口"



\# 第二次提交：分类规则模块

git add course\_organizer/rules.py

git commit -m "feat: 实现分类规则模块，支持关键字优先+后缀匹配"



\# 第三次提交：核心逻辑基础版

git add course\_organizer/core.py

git commit -m "feat: 完成文件扫描、整理计划生成、重名冲突处理"



\# 第四次提交：执行与报告功能

git add course\_organizer/core.py main.py

git commit -m "feat: 支持dry-run预览、copy/move执行、生成整理报告"



\# 第五次提交：完善文档与测试素材

git add README.md sample\_materials/

git commit -m "docs: 完善README说明，添加测试素材文件"

