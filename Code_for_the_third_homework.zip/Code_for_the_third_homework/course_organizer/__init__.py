"""课程资料自动整理器功能包"""
__all__ = ["get_file_category", "build_organize_plan", "execute_plan", "generate_report"]

from .rules import get_file_category
from .core import build_organize_plan, execute_plan, generate_report