from pathlib import Path
import shutil
from collections import defaultdict
from .rules import get_file_category


def resolve_dup_path(dst_path: Path) -> Path:
    """
    处理目标文件重名冲突，自动追加 _1 / _2 后缀，永不覆盖原有文件
    """
    if not dst_path.exists():
        return dst_path
    stem = dst_path.stem
    suffix = dst_path.suffix
    parent = dst_path.parent
    index = 1
    while True:
        new_name = f"{stem}_{index}{suffix}"
        new_path = parent / new_name
        if not new_path.exists():
            return new_path
        index += 1


def scan_source_files(source_dir: Path):
    """
    扫描源目录下的所有文件（仅当前层级，不递归子目录）
    """
    file_list = []
    for item in source_dir.iterdir():
        if item.is_file():
            file_list.append(item)
    return file_list


def build_organize_plan(source_dir: Path, target_dir: Path):
    """
    生成完整整理计划，不执行任何文件操作
    返回格式：[(源路径, 目标路径, 分类), ...]
    """
    plan = []
    files = scan_source_files(source_dir)
    for src_path in files:
        category = get_file_category(src_path)
        category_dir = target_dir / category
        raw_target = category_dir / src_path.name
        safe_target = resolve_dup_path(raw_target)
        plan.append((src_path, safe_target, category))
    return plan


def execute_plan(plan, dry_run: bool, mode: str = "copy"):
    """
    执行整理计划
    :param plan: 整理计划列表
    :param dry_run: True=仅预览不操作文件
    :param mode: copy=复制（默认）/ move=移动
    """
    if dry_run:
        print("=" * 50)
        print("DRY-RUN 整理计划预览（不创建目录、不修改任何文件）")
        print("=" * 50)
        for src, dst, cat in plan:
            print(f"【{cat}】{src.name}  →  {dst}")
        return

    # 真实执行：先批量创建所有分类目录
    all_categories = {item[2] for item in plan}
    target_root = plan[0][1].parent.parent
    for cat in all_categories:
        (target_root / cat).mkdir(parents=True, exist_ok=True)

    # 批量执行复制/移动
    for src, dst, cat in plan:
        if mode == "copy":
            shutil.copy2(src, dst)
        elif mode == "move":
            shutil.move(src, dst)
        print(f"已完成【{cat}】{src.name} → {dst}")


def generate_report(target_dir: Path, plan, mode: str):
    """
    在目标目录生成 整理报告.txt
    包含：操作模式、文件总数、文件迁移明细、各分类数量统计
    """
    report_path = target_dir / "整理报告.txt"
    category_count = defaultdict(int)
    file_records = []
    total = len(plan)

    for src, dst, cat in plan:
        category_count[cat] += 1
        file_records.append(f"源文件：{src}\n目标路径：{dst}\n分类：{cat}\n")

    # 组装报告内容
    report_content = []
    report_content.append("=" * 50)
    report_content.append("课程资料整理报告")
    report_content.append("=" * 50)
    report_content.append(f"操作模式：{'复制（保留原文件）' if mode == 'copy' else '移动（剪切原文件）'}")
    report_content.append(f"本次整理文件总数：{total}")
    report_content.append("\n各分类文件统计：")
    for cat, cnt in sorted(category_count.items()):
        report_content.append(f"  {cat}：{cnt} 个")
    report_content.append("\n" + "=" * 50)
    report_content.append("文件迁移明细：")
    report_content.append("=" * 50)
    report_content.extend(file_records)

    report_text = "\n".join(report_content)
    report_path.write_text(report_text, encoding="utf-8")
    print(f"\n整理报告已生成：{report_path.resolve()}")