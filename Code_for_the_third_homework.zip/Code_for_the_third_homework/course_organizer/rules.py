# 优先级1：作业类关键字，匹配成功直接归入 homework
HOMEWORK_KEYWORDS = {"作业", "练习", "实验", "任务"}

# 优先级2：后缀名 → 分类目录 映射表
SUFFIX_CATEGORY_MAP = {
    ".ppt": "slides",
    ".pptx": "slides",
    ".key": "slides",

    ".py": "code",
    ".ipynb": "code",
    ".c": "code",
    ".cpp": "code",
    ".java": "code",

    ".csv": "data",
    ".xlsx": "data",
    ".json": "data",

    ".pdf": "documents",
    ".doc": "documents",
    ".docx": "documents",
    ".txt": "documents",
    ".md": "documents",

    ".png": "images",
    ".jpg": "images",
    ".jpeg": "images",
    ".gif": "images",
}


def get_file_category(file_path):
    """
    判断单个文件的分类目录
    规则优先级：作业关键字 > 文件后缀
    :param file_path: pathlib.Path 对象
    :return: 分类目录名（str）
    """
    filename = file_path.name
    # 优先匹配作业关键字
    for keyword in HOMEWORK_KEYWORDS:
        if keyword in filename:
            return "homework"
    # 后缀匹配（统一转小写，兼容大小写后缀）
    suffix = file_path.suffix.lower()
    if suffix in SUFFIX_CATEGORY_MAP:
        return SUFFIX_CATEGORY_MAP[suffix]
    # 无法识别归入其他
    return "others"